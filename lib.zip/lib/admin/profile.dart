import 'package:flutter/material.dart';
import 'package:quizmanage/admin/Dashboard.dart';
import 'package:page_transition/page_transition.dart';
import 'package:quizmanage/admin/Histort.dart';
import 'package:quizmanage/loginPage.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:quizmanage/admin/NotificationPage.dart';
import 'package:quizmanage/admin/uploadQB.dart';

class ProPage extends StatefulWidget {
  const ProPage({super.key});

  @override
  State<ProPage> createState() => _ProPageState();
}

class _ProPageState extends State<ProPage> {

  Future<void> logout(BuildContext context) async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    await prefs.clear();
    Navigator.pushAndRemoveUntil(
      context,
      MaterialPageRoute(builder: (context) => const Loginpage()),
          (route) => false,
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.blueAccent,
      appBar: AppBar(
        title: Text("Your Profile"),
        centerTitle: true,
        backgroundColor: Colors.lightBlueAccent,
      ),
      body: Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(colors: [Colors.white38,Colors.lightBlueAccent],
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
          ),
        ),
        child: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Column(
            children: [
              Center(
                child: Column(
                  children: [
                    Stack(
                      children: [
                        CircleAvatar(
                          radius: 50,
                          backgroundColor: Colors.grey[400],
                          child: Icon(Icons.person, size: 50, color: Colors.white),
                        ),
                        Positioned(
                          bottom: 0,
                          right: 0,
                          child: CircleAvatar(
                            radius: 15,
                            backgroundColor: Colors.black,
                            child: Icon(Icons.edit, size: 15, color: Colors.white),
                          ),
                        ),
                      ],
                    ),
                    SizedBox(height: 10),
                    Text(
                      "Username",
                      style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                    ),
                    Container(
                      margin: EdgeInsets.only(top: 5),
                      padding: EdgeInsets.symmetric(horizontal: 10, vertical: 5),
                      decoration: BoxDecoration(
                        color: Colors.black,
                        borderRadius: BorderRadius.circular(10),
                      ),
                      child: Text(
                        "Admin",
                        style: TextStyle(color: Colors.white, fontSize: 12),
                      ),
                    ),
                  ],
                ),
              ),
              SizedBox(height: 30),
              Expanded(
                child: ListView(
                  children: [
                    _buildListItem(Icons.home, "Home",()=>Navigator.push(context, PageTransition(child: AdminDashboard(), type: PageTransitionType.fade))),
                    SizedBox(height: 15),
                    _buildListItem(Icons.history, "History",()=>Navigator.push(context, PageTransition(child: const HisPage(), type: PageTransitionType.fade))),
                    SizedBox(height: 15),
                    _buildListItem(Icons.upload_file, "Upload Question Bank",()=>Navigator.push(context, PageTransition(child: const Uploadqb(), type: PageTransitionType.fade))),
                    SizedBox(height: 15),
                    _buildListItem(Icons.notification_add, "Notifications",()=>Navigator.push(context, PageTransition(child: const Notificationpage(), type: PageTransitionType.fade))),
                  ],
                ),
              ),
              SizedBox(height: 10),
              _buildButton(Icons.logout, "Log out", Colors.grey[300]!,()=>logout(context)),
              SizedBox(height: 10),
              _buildButton(Icons.delete, "Delete account", Colors.red,()=>logout(context)),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildListItem(IconData icon, String title,VoidCallback onTap) {
    return ListTile(
      leading: CircleAvatar(
        backgroundColor: Colors.grey[300],
        child: Icon(icon, color: Colors.black),
      ),
      title: Text(title, style: TextStyle(fontSize: 20)),
      trailing: Icon(Icons.arrow_forward_ios, size: 20),
      onTap: onTap
    );
  }

  Widget _buildButton(IconData icon, String text, Color color,VoidCallback onPressed) {
    return ElevatedButton(
      style: ElevatedButton.styleFrom(
        backgroundColor: color,
        minimumSize: Size(double.infinity, 50),
        elevation: 0,
      ),
      onPressed: onPressed,
      child: Row(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(icon, color: Colors.black),
          SizedBox(width: 10),
          Text(
            text,
            style: TextStyle(color: Colors.black, fontSize: 16),
          ),
        ],
      ),
    );
  }
}