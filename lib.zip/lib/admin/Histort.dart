import 'package:flutter/material.dart';
import 'package:page_transition/page_transition.dart';

class HisPage extends StatefulWidget {
  const HisPage({super.key});

  @override
  State<HisPage> createState() => _HisPageState();
}

class _HisPageState extends State<HisPage> {
  @override
  Widget build(BuildContext context) {
    final List<Map<String, dynamic>> quizHistory = [
      {
        "title": "Quiz 1",
        "questions": 15,
        "category": "GK",
        "createdAt": "01/02/2024",
        "updatedAt": "02/02/2024",
      },
      {
        "title": "Quiz 2",
        "questions": 20,
        "category": "GK",
        "createdAt": "05/01/2024",
        "updatedAt": "10/01/2024",
      },
      {
        "title": "Quiz 3",
        "questions": 10,
        "category": "GK",
        "createdAt": "15/12/2023",
        "updatedAt": "20/12/2023",
      },
      {
        "title": "Quiz 4",
        "questions": 25,
        "category": "GK",
        "createdAt": "28/11/2023",
        "updatedAt": "30/11/2023",
      },
    ];
    TextEditingController searchController = TextEditingController();
    return Scaffold(
      backgroundColor: Colors.blueAccent,
      appBar: AppBar(
        title: Text("History"),
        centerTitle: true,
        backgroundColor: Colors.lightBlueAccent,
      ),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: TextField(
              controller: searchController,
              decoration: InputDecoration(
                filled: true,
                focusColor: Colors.white,
                hintText: "Search Quizzes here...",
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(8),
                ),
                prefixIcon: Icon(Icons.search),
              ),
            ),
          ),
          Expanded(
            child: Container(
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: [Colors.white38, Colors.lightBlueAccent],
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                ),
              ),
              child: Padding(
                padding: const EdgeInsets.all(16.0),
                child: ListView.builder(
                  itemCount: quizHistory.length,
                  itemBuilder: (context, index) {
                    final quiz = quizHistory[index];
                    return Card(
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                      margin: EdgeInsets.only(bottom: 12),
                      child: Padding(
                        padding: const EdgeInsets.all(12.0),
                        child: Row(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Container(
                              width: 60,
                              height: 60,
                              decoration: BoxDecoration(
                                color: Colors.grey[300],
                                borderRadius: BorderRadius.circular(8),
                              ),
                            ),
                            SizedBox(width: 16),
                            Expanded(
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text(
                                    quiz["title"],
                                    style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                                  ),
                                  SizedBox(height: 4),
                                  Text(
                                    "${quiz["questions"]} Questions",
                                    style: TextStyle(fontSize: 14, color: Colors.grey[700]),
                                  ),
                                  Text(
                                    "Category: ${quiz["category"]}",
                                    style: TextStyle(fontSize: 14, color: Colors.grey[700]),
                                  ),
                                  SizedBox(height: 4),
                                  Text(
                                    "Created at: ${quiz["createdAt"]}",
                                    style: TextStyle(fontSize: 12, color: Colors.grey[600]),
                                  ),
                                  Text(
                                    "Updated at: ${quiz["updatedAt"]}",
                                    style: TextStyle(fontSize: 12, color: Colors.grey[600]),
                                  ),
                                ],
                              ),
                            ),
                          ],
                        ),
                      ),
                    );
                  },
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}