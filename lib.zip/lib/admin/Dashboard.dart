import 'package:flutter/material.dart';
import 'package:carousel_slider/carousel_slider.dart';
import 'package:quizmanage/admin/EditQuiz.dart';
import 'package:quizmanage/admin/Histort.dart';
import 'package:quizmanage/admin/addQuiz.dart';
import 'package:quizmanage/admin/profile.dart';
import 'package:page_transition/page_transition.dart';
import 'package:quizmanage/Datahelp/tables.dart';

class AdminDashboard extends StatefulWidget {
  @override
  _AdminDashboardState createState() => _AdminDashboardState();
}

class _AdminDashboardState extends State<AdminDashboard> {
  int _selectedIndex = 0;
  String username = "Loading...";
  List<Map<String, dynamic>> quizzes = [];

  static final List<Widget> _pages = <Widget>[
    Dashb(),
    ProPage(),
    HisPage(),
  ];

  void _onItemTapped(int index) {
    setState(() {
      _selectedIndex = index;
    });
  }

  @override
  void initState() {
    super.initState();
    fetchUserData();
    fetchQuizzes();
  }

  Future<void> fetchUserData() async {
    Map<String, dynamic>? admin = await DatabaseHelper.instance.getAdmin();
    if (admin != null) {
      setState(() {
        username = admin['name'];
      });
    }
  }

  Future<void> fetchQuizzes() async {
    List<Map<String, dynamic>> result = await DatabaseHelper.instance.fetchQuizzes();
    setState(() {
      quizzes = result;
    });
  }

  Future<void> deleteQuiz(int id) async {
    await DatabaseHelper.instance.deleteQuiz(id);
    fetchQuizzes();
  }

  Future<void> addQuiz(String title, String category, String date, String question, String optionA, String optionB, String optionC, String optionD, String correctAnswer) async {
    await DatabaseHelper.instance.insertQuiz({
      'title': title,
      'category': category,
      'date': date,
      'question': question,
      'optionA': optionA,
      'optionB': optionB,
      'optionC': optionC,
      'optionD': optionD,
      'correct_answer': correctAnswer,
    });
    fetchQuizzes();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.blueAccent,
      body: _pages[_selectedIndex],
      bottomNavigationBar: BottomNavigationBar(
        items: const <BottomNavigationBarItem>[
          BottomNavigationBarItem(icon: Icon(Icons.home), label: 'Home'),
          BottomNavigationBarItem(icon: Icon(Icons.person), label: 'Profile'),
          BottomNavigationBarItem(icon: Icon(Icons.history), label: 'History'),
        ],
        currentIndex: _selectedIndex,
        selectedItemColor: Colors.blue,
        onTap: _onItemTapped,
      ),
    );
  }
}

class Dashb extends StatefulWidget {
  @override
  _DashbState createState() => _DashbState();
}

class _DashbState extends State<Dashb> {
  String username = "Loading...";
  List<Map<String, dynamic>> quizzes = [];

  @override
  void initState() {
    super.initState();
    fetchUserData();
    fetchQuizzes();
  }

  Future<void> fetchUserData() async {
    Map<String, dynamic>? admin = await DatabaseHelper.instance.getAdmin();
    if (admin != null) {
      setState(() {
        username = admin['name'];
      });
    }
  }

  Future<void> fetchQuizzes() async {
    List<Map<String, dynamic>> result = await DatabaseHelper.instance.fetchQuizzes();
    setState(() {
      quizzes = result;
    });
  }

  Future<void> deleteQuiz(int id) async {
    await DatabaseHelper.instance.deleteQuiz(id);
    fetchQuizzes();
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        gradient: LinearGradient(colors: [Colors.white38, Colors.lightBlueAccent],
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
        ),
      ),
      child: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                CircleAvatar(child: Icon(Icons.person)),
                SizedBox(width: 10),
                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(username, style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
                    Container(
                      padding: EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                      decoration: BoxDecoration(
                        color: Colors.grey[300],
                        borderRadius: BorderRadius.circular(8),
                      ),
                      child: Text("Admin", style: TextStyle(fontSize: 12)),
                    ),
                  ],
                ),
              ],
            ),
            SizedBox(height: 20),
            Center(
              child: ElevatedButton(
                onPressed: () {
                  Navigator.push(context, PageTransition(child: Addquiz(), type: PageTransitionType.fade));
                },
                child: Text("Add Quiz"),
              ),
            ),
            SizedBox(height: 20),
            Expanded(
              child: GridView.builder(
                padding: EdgeInsets.all(8),
                gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                  crossAxisCount: 2,
                  crossAxisSpacing: 20,
                  mainAxisSpacing: 20,
                  childAspectRatio: 0.8,
                ),
                itemCount: quizzes.length,
                itemBuilder: (context, index) {
                  final quiz = quizzes[index];
                  return Container(
                    padding: EdgeInsets.all(8),
                    decoration: BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.circular(10),
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Expanded(child: Container(color: Colors.grey[300])),
                        SizedBox(height: 10),
                        Text(quiz['title'], style: TextStyle(fontWeight: FontWeight.bold)),
                        Text("${quiz['question_count']} Questions"),
                        Text("Tag: ${quiz['tag']}", style: TextStyle(color: Colors.blueGrey)),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            IconButton(
                              onPressed: () {
                                Navigator.push(context, PageTransition(child: Editquiz(quiz: quiz), type: PageTransitionType.fade));
                              },
                              icon: Icon(Icons.edit, size: 18),
                            ),
                            IconButton(
                              onPressed: () {
                                deleteQuiz(quiz['id']);
                              },
                              icon: Icon(Icons.delete, size: 18, color: Colors.red),
                            ),
                          ],
                        )
                      ],
                    ),
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }
}
