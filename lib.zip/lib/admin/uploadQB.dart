import 'package:flutter/material.dart';
import 'package:quizmanage/admin/Dashboard.dart';
import 'package:quizmanage/admin/profile.dart';
import 'package:page_transition/page_transition.dart';

class Uploadqb extends StatefulWidget {
  const Uploadqb({super.key});

  @override
  State<Uploadqb> createState() => _UploadqbState();
}

class _UploadqbState extends State<Uploadqb> {
  TextEditingController _titleController = TextEditingController();
  TextEditingController _dateController = TextEditingController();
  TextEditingController _authorController = TextEditingController();
  double? _uploadProgress;
  String? _fileName;

  Future<void> _pickDate(BuildContext context) async {
    DateTime? pickedDate = await showDatePicker(
      context: context,
      initialDate: DateTime.now(),
      firstDate: DateTime(2000),
      lastDate: DateTime(2100),
    );

    if (pickedDate != null) {
      setState(() {
        _dateController.text =
        "${pickedDate.day}/${pickedDate.month}/${pickedDate.year}";
      });
    }
  }

  void _simulateUpload() {
    setState(() {
      _uploadProgress = 0.0;
    });

    Future.delayed(Duration(seconds: 2), () {
      setState(() {
        _uploadProgress = 1.0;
      });
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.lightBlueAccent,
      appBar: AppBar(
        title: Text("Upload Question Bank"),
        centerTitle: true,
        backgroundColor: Colors.blueAccent,
        leading: IconButton(
          icon: Icon(Icons.arrow_back),
          onPressed: () {
            Navigator.push(
              context,
              PageTransition(
                  child: AdminDashboard(), type: PageTransitionType.fade),
            );
          },
        ),
      ),
      body: Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            colors: [Colors.white38, Colors.lightBlueAccent],
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
          ),
        ),
        child: SingleChildScrollView( // Prevents overflow errors
          child: Padding(
            padding: const EdgeInsets.all(16.0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                // QB Title
                Text(
                  "QB Title:",
                  style: TextStyle(
                      fontSize: 15, fontWeight: FontWeight.bold, color: Colors.black),
                ),
                TextField(
                  controller: _titleController,
                  decoration: InputDecoration(
                    filled: true,
                    border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
                    hintText: "Enter Question Bank Title",
                  ),
                ),
                SizedBox(height: 10),

                // Date Picker
                Text(
                  "Date:",
                  style: TextStyle(
                      fontSize: 15, fontWeight: FontWeight.bold, color: Colors.black),
                ),
                TextField(
                  controller: _dateController,
                  readOnly: true,
                  decoration: InputDecoration(
                    filled: true,
                    border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
                    hintText: "DD/MM/YYYY",
                    suffixIcon: IconButton(
                      icon: Icon(Icons.calendar_today),
                      onPressed: () => _pickDate(context),
                    ),
                  ),
                ),
                SizedBox(height: 10),

                // File Selection
                Text(
                  "Select File:",
                  style: TextStyle(
                      fontSize: 15, fontWeight: FontWeight.bold, color: Colors.black),
                ),
                Row(
                  children: [
                    Expanded(
                      child: Container(
                        padding: EdgeInsets.symmetric(vertical: 10, horizontal: 12),
                        decoration: BoxDecoration(
                          color: Colors.grey[200],
                          border: Border.all(color: Colors.grey),
                          borderRadius: BorderRadius.circular(12),
                        ),
                        child: Text(_fileName ?? "No file chosen"),
                      ),
                    ),
                    SizedBox(width: 10),
                    ElevatedButton(
                      onPressed: () {
                        setState(() {
                          _fileName = "Sample_File.pdf";
                        });
                      },
                      child: Text(
                        "Choose",
                        style: TextStyle(
                            color: Colors.black,
                            fontWeight: FontWeight.bold,
                            fontSize: 18),
                      ),
                    ),
                  ],
                ),
                SizedBox(height: 10),

                // Author
                Text(
                  "Author:",
                  style: TextStyle(
                      fontSize: 15, fontWeight: FontWeight.bold, color: Colors.black),
                ),
                TextField(
                  controller: _authorController,
                  decoration: InputDecoration(
                    filled: true,
                    border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
                    hintText: "Enter Author Name",
                  ),
                ),
                SizedBox(height: 20),

                // Progress Indicator (if uploading)
                if (_uploadProgress != null) ...[
                  SizedBox(
                    height: 5, // Prevents RenderFlex issue
                    child: LinearProgressIndicator(value: _uploadProgress),
                  ),
                  SizedBox(height: 10),
                ],

                // Upload Button
                Center(
                  child: ElevatedButton(
                    onPressed: _simulateUpload,
                    style: ElevatedButton.styleFrom(
                      minimumSize: Size(double.infinity, 45),
                    ),
                    child: Text(
                      "Upload",
                      style: TextStyle(
                          color: Colors.black, fontWeight: FontWeight.bold, fontSize: 18),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
