import 'package:flutter/material.dart';
import 'package:quizmanage/admin/Dashboard.dart';
import 'package:page_transition/page_transition.dart';
import 'package:quizmanage/admin/EditExisting.dart';
import 'package:quizmanage/admin/extraQues.dart';

class Editquiz extends StatelessWidget {
  const Editquiz({super.key, required Map<String, dynamic> quiz});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.blueAccent,
      appBar: AppBar(
        title: Text("Edit Quiz"),
        centerTitle: true,
        backgroundColor: Colors.lightBlueAccent,
        leading: IconButton(
          icon: Icon(Icons.arrow_back),
          onPressed: () {
            Navigator.push(context, PageTransition(child: AdminDashboard(), type: PageTransitionType.fade));
          },
        ),
      ),
      body: Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(colors: [Colors.white38,Colors.lightBlueAccent],
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
          ),
        ),
        child: Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Container(
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                      colors: [Colors.blue,Colors.purpleAccent]
                  ),
                  borderRadius: BorderRadius.circular(8)
                ),
                child: SizedBox(
                  width: 300,
                  height: 50,
                  child: ElevatedButton(
                    onPressed: () {
                      Navigator.push(context, PageTransition(
                        type: PageTransitionType.leftToRightWithFade,
                        child: Extraques(),
                        duration: Duration(milliseconds: 500),
                      ),);
                    },style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.transparent,
                      shadowColor: Colors.transparent,
                      padding: EdgeInsets.symmetric(horizontal: 24, vertical: 12),
                      ),
                      child: Text("Add Question",style: TextStyle(fontSize: 16,color: Colors.white,fontWeight: FontWeight.bold),),
                  ),
                ),
              ),
              SizedBox(height: 20),
              Container(
                decoration: BoxDecoration(
                    gradient: LinearGradient(colors:
                    [Colors.blue,Colors.purpleAccent]
                    ),
                    borderRadius: BorderRadius.circular(8)
                ),
                child: SizedBox(
                  width: 300,
                  height: 50,
                  child: ElevatedButton(
                    onPressed: () {
                      Navigator.push(context, PageTransition(
                        type: PageTransitionType.leftToRightWithFade,
                        child: Editexisting(),
                        duration: Duration(milliseconds: 500),
                      ),);
                    },style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.transparent,
                      shadowColor: Colors.transparent,
                      padding: EdgeInsets.symmetric(horizontal: 24, vertical: 12),
                  ),
                    child: Text("Edit Existing Question",style: TextStyle(fontSize: 16,color: Colors.white,fontWeight: FontWeight.bold),),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}