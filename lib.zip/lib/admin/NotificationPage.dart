import 'package:flutter/material.dart';
import 'package:page_transition/page_transition.dart';
import 'package:quizmanage/admin/Dashboard.dart';

class Notificationpage extends StatelessWidget {
  const Notificationpage({super.key});

  @override
  Widget build(BuildContext context) {
    final List<Map<String, dynamic>> notifications = [
      {"name": "name", "category": "Maths", "correct": "12/15", "rating": 3},
      {"name": "name2", "category": "GK", "correct": "14/20", "rating": 4},
      {"name": "name3", "category": "Maths", "correct": "17/25", "rating": 2},
      {"name": "name4", "category": "GK", "correct": "08/15", "rating": 5},
      {"name": "name5", "category": "Physics", "correct": "22/30", "rating": 3},
    ];
    return Scaffold(
      backgroundColor: Colors.lightBlueAccent,
      appBar: AppBar(
        leading: IconButton(
          icon: const Icon(Icons.arrow_back),
          onPressed: () {
            Navigator.push(context, PageTransition(child: AdminDashboard(), type: PageTransitionType.fade));
          },
        ),
        title: const Text("Notifications"),
        centerTitle: true,
        backgroundColor: Colors.blueAccent,
      ),
      body: Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(colors: [Colors.white38,Colors.lightBlueAccent],
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
          ),
        ),
        child: Padding(
          padding: const EdgeInsets.all(10.0),
          child: ListView.builder(
            itemCount: notifications.length,
            itemBuilder: (context, index) {
              final notification = notifications[index];
              return Card(
                elevation: 3,
                margin: const EdgeInsets.symmetric(vertical: 5),
                child: Padding(
                  padding: const EdgeInsets.all(10.0),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        notification["name"],
                        style: const TextStyle(
                          fontSize: 16,
                          fontWeight: FontWeight.bold,
                          color: Colors.blue,
                        ),
                      ),
                      Text("Category: ${notification["category"]}"),
                      Text("Correct: ${notification["correct"]}"),
                      const SizedBox(height: 5),
                      Row(
                        children: [
                          const Text(
                            "Rating: ",
                            style: TextStyle(fontWeight: FontWeight.bold,fontSize: 18),
                          ),
                          Row(
                            children: List.generate(5, (i) {
                              return Icon(
                                i < notification["rating"]
                                    ? Icons.star
                                    : Icons.star_border,
                                color: Colors.amber,
                              );
                            }),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
              );
            },
          ),
        ),
      ),
    );
  }
}
