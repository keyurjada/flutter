import 'package:flutter/material.dart';
import 'package:quizmanage/admin/Dashboard.dart';
import 'package:page_transition/page_transition.dart';

class Addquiz extends StatelessWidget {
  const Addquiz({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.blueAccent,
      appBar: AppBar(
        title: Text("Add Quiz"),
        backgroundColor: Colors.blueAccent,
        centerTitle: true,
        leading: IconButton(
          icon: Icon(Icons.arrow_back),
          onPressed: () {
            Navigator.push(
              context,
              PageTransition(child: AdminDashboard(), type: PageTransitionType.fade),
            );
          },
        ),
      ),
      body: Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            colors: [Colors.white38, Colors.lightBlueAccent],
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
          ),
        ),
        child: SingleChildScrollView(
          child: Padding(
            padding: const EdgeInsets.all(16.0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                buildTextField("Quiz Title"),
                SizedBox(height: 10),
                buildTextField("Quiz Category"),
                SizedBox(height: 10),
                buildTextField("Quiz Date (DD-MM-YYYY)", isDate: true),
                SizedBox(height: 10),
                Text("Your Question:", style: TextStyle(fontWeight: FontWeight.bold, fontSize: 20)),
                buildTextField("Question ?"),
                SizedBox(height: 10),

                // Answer Options (Using Flexible inside Row)
                Row(
                  children: [
                    Flexible(child: buildTextField("A)")),
                    SizedBox(width: 10),
                    Flexible(child: buildTextField("B)")),
                  ],
                ),
                SizedBox(height: 10),
                Row(
                  children: [
                    Flexible(child: buildTextField("C)")),
                    SizedBox(width: 10),
                    Flexible(child: buildTextField("D)")),
                  ],
                ),
                SizedBox(height: 10),

                Text("Correct Answer:", style: TextStyle(fontWeight: FontWeight.bold, fontSize: 20)),
                buildTextField(""),

                SizedBox(height: 30),

                Center(
                  child: SizedBox(
                    width: double.infinity,
                    height: 50,
                    child: ElevatedButton(
                      onPressed: () {
                        print("Made...!");
                      },
                      style: ElevatedButton.styleFrom(
                        backgroundColor: Colors.white,
                      ),
                      child: Text(
                        "Make It",
                        style: TextStyle(fontWeight: FontWeight.bold, color: Colors.black, fontSize: 20),
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
  Widget buildTextField(String hint, {bool isDate = false}) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 5.0),
      child: Container(
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(12),
          boxShadow: [
            BoxShadow(
              color: Colors.grey.withOpacity(0.3),
              spreadRadius: 2,
              blurRadius: 5,
              offset: Offset(0, 3),
            ),
          ],
        ),
        child: TextField(
          readOnly: isDate,
          decoration: InputDecoration(
            hintText: hint,
            border: OutlineInputBorder(
              borderRadius: BorderRadius.circular(12),
              borderSide: BorderSide.none,
            ),
            filled: true,
            fillColor: Colors.white,
            prefixIcon: Icon(Icons.edit, color: Colors.blueAccent),
            contentPadding: EdgeInsets.symmetric(vertical: 15, horizontal: 20),
            suffixIcon: isDate
                ? IconButton(
              icon: Icon(Icons.calendar_today),
              onPressed: () {
                // Add date picker functionality
              },
            )
                : null,
          ),
        ),
      ),
    );
  }
}
