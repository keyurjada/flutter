import 'package:sqflite/sqflite.dart';
import 'package:path/path.dart';
import 'package:path_provider/path_provider.dart';
import 'package:crypto/crypto.dart';
import 'dart:convert';

class DatabaseHelper {
  static final DatabaseHelper instance = DatabaseHelper._init();
  static Database? _database;

  DatabaseHelper._init();

  Future<Database> get database async {
    if (_database != null) return _database!;

    _database = await _initDB('data.db');
    return _database!;
  }

  Future<Database> _initDB(String filePath) async {
    final dir = await getApplicationDocumentsDirectory();
    final path = join(dir.path, filePath);
    return openDatabase(path, version: 2, onCreate: _createDB);
  }

  Future _createDB(Database db, int version) async {
    await db.execute('''
      CREATE TABLE category (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL
      );
    '''
    );

    await db.execute('''
      CREATE TABLE users (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        email TEXT NOT NULL UNIQUE,
        phone TEXT NOT NULL,
        password TEXT NOT NULL,
        role TEXT CHECK(role IN ('admin', 'user')) DEFAULT 'user'
      );
    ''');

    await db.execute('''
      CREATE TABLE quiz (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        title TEXT NOT NULL,
        category_id INTEGER NOT NULL,
        question_count INTEGER NOT NULL DEFAULT 0,
        tag TEXT,
        created_at TEXT NOT NULL,
        FOREIGN KEY (category_id) REFERENCES category (id) ON DELETE CASCADE
      );
    ''');

    await db.execute('''
      CREATE TABLE questions (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        quiz_id INTEGER NOT NULL,
        question_text TEXT NOT NULL,
        FOREIGN KEY (quiz_id) REFERENCES quiz (id) ON DELETE CASCADE
      );
    ''');

    await db.execute('''
      CREATE TABLE answers (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        question_id INTEGER NOT NULL,
        answer_text TEXT NOT NULL,
        is_correct INTEGER NOT NULL CHECK(is_correct IN (0,1)),
        FOREIGN KEY (question_id) REFERENCES questions (id) ON DELETE CASCADE
      );
    ''');

    await db.execute('''
      CREATE TABLE scores (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER NOT NULL,
        quiz_id INTEGER NOT NULL,
        score INTEGER NOT NULL,
        FOREIGN KEY (user_id) REFERENCES users (id) ON DELETE CASCADE,
        FOREIGN KEY (quiz_id) REFERENCES quiz (id) ON DELETE CASCADE
      );
    ''');
  }

  Future<Map<String, dynamic>?> getAdmin() async {
    final db = await instance.database;
    List<Map<String, dynamic>> result = await db.query(
        'users',
        where: "role = ?",
        whereArgs: ['admin'],
        limit: 1
    );
    return result.isNotEmpty ? result.first : null;
  }

  Future<List<Map<String, dynamic>>> fetchQuizzes() async {
    final db = await instance.database;
    return await db.query('quiz');
  }

  Future<int> updateQuiz(int id, String title, String tag, int questionCount) async {
    final db = await instance.database;
    return await db.update(
      'quiz',
      {'title': title, 'tag': tag, 'question_count': questionCount},
      where: 'id = ?',
      whereArgs: [id],
    );
  }

  Future<int> deleteQuiz(int id) async {
    final db = await instance.database;
    return await db.delete('quiz', where: 'id = ?', whereArgs: [id]);
  }

  Future<int> signup({
    required String role,
    required String name,
    required String email,
    required String password,
    required String phone
  }) async {
    final db = await instance.database;
    String hashedPassword = sha256.convert(utf8.encode(password)).toString();
    final Map<String, dynamic> data = {
      'role': role,
      'name': name,
      'email': email,
      'password': hashedPassword,
      'phone' : phone
    };
    final tables = await db.rawQuery("SELECT name FROM sqlite_master WHERE type='table'");
    print("Database Tables: $tables");

    return await db.insert('users', data);
  }

  Future<Map<String, dynamic>?> login({
    required String email,
    required String password,
  }) async {
    final db = await instance.database;
    String hashedPassword = sha256.convert(utf8.encode(password)).toString();
    List<Map<String, dynamic>> result = await db.query(
      'users',
      where: 'email = ? AND password = ?',
      whereArgs: [email, hashedPassword],
    );
    if (result.isNotEmpty) {
      return result.first;
    } else {
      return null;
    }
  }
}
