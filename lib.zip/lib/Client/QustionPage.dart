import 'package:flutter/material.dart';
import 'package:page_transition/page_transition.dart';

class QuesScreen extends StatefulWidget {
  @override
  _QuizScreenState createState() => _QuizScreenState();
}

class _QuizScreenState extends State<QuesScreen> {
  double progress = 0.4;
  int selectedOption = -1;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.blueAccent,
      appBar: AppBar(
        title: const Text("Question 3/15"),
        backgroundColor: Colors.lightBlueAccent,
      ),
      body: Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(colors: [Colors.white38,Colors.lightBlueAccent],
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
          ),
        ),
        child: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              Container(
                padding: const EdgeInsets.all(16.0),
                decoration: BoxDecoration(
                  color: Colors.grey[300],
                  borderRadius: BorderRadius.circular(12),
                ),
                child: const Text(
                  "Which soccer team won the FIFA World Cup for the first time?",
                  textAlign: TextAlign.center,
                  style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                ),
              ),
              const SizedBox(height: 20),
              LinearProgressIndicator(
                value: progress,
                minHeight: 8,
                backgroundColor: Colors.grey[300],
                valueColor: AlwaysStoppedAnimation<Color>(Colors.red),
              ),
              const SizedBox(height: 20),
              for (int i = 0; i < 4; i++) _buildOption(i),
              const SizedBox(height: 20),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  ElevatedButton(
                    onPressed: () {
                      print("50/50");
                    },style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.deepOrange
                    ),
                    child: const Text("50/50",style: TextStyle(color: Colors.white,fontWeight: FontWeight.bold),),
                  ),
                  ElevatedButton(
                    onPressed: () {
                      print("skipped and next");
                    },style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.deepOrange
                    ),
                    child: const Text("Skip >>",style: TextStyle(color: Colors.white,fontWeight: FontWeight.bold),),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
  Widget _buildOption(int index) {
    List<String> options = ["A) Brazil", "B) Uruguay", "C) Italy", "D) Germany"];
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 10),
      child: ElevatedButton(
        onPressed: () {
          setState(() {
            selectedOption = index;
          });
        },
        style: ElevatedButton.styleFrom(
          backgroundColor: selectedOption == index ? Colors.blue : Colors.grey[600],
          foregroundColor: Colors.white,
          padding: const EdgeInsets.all(16),
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
        ),
        child: Align(
          alignment: Alignment.centerLeft,
          child: Text(
            options[index],
            style: const TextStyle(fontSize: 16),
          ),
        ),
      ),
    );
  }
}