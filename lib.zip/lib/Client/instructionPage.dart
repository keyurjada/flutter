import 'package:flutter/material.dart';
import 'package:quizmanage/Client/Dashboard.dart';
import 'package:page_transition/page_transition.dart';
import 'package:quizmanage/Client/QustionPage.dart';

class Instruct extends StatelessWidget {
  const Instruct({super.key});

  @override
  Widget build(BuildContext context) {
    final List<String> instructions = [
      "1. Read each question carefully before answering.",
      "2. There is no negative marking, so attempt all questions.",
      "3. You have a limited time to complete the quiz.",
      "4. Once submitted, you cannot change your answers.",
      "5. Make sure you have a stable internet connection.",
    ];
    return Scaffold(
      backgroundColor: Colors.blueAccent,
      appBar: AppBar(
        title: Center(child: Text("Special GK Quiz")),
        backgroundColor: Colors.lightBlueAccent,
        leading: IconButton(
          icon: Icon(Icons.arrow_back),
          onPressed: () {
            Navigator.push(context, MaterialPageRoute(builder: (context)=>MainPage()));
          },
        ),
      ),
      body: Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(colors: [Colors.white38,Colors.lightBlueAccent],
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
          ),
        ),
        child: SafeArea(
          child: Padding(
            padding: const EdgeInsets.all(16.0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const SizedBox(height: 10),
                const SizedBox(height: 20),
                Expanded(
                  child: Container(
                    padding: const EdgeInsets.all(16),
                    decoration: BoxDecoration(
                      color: Colors.white60,
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const Text(
                          "Instructions",
                          style: TextStyle(
                            fontSize: 18,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                        const SizedBox(height: 10),
                        Expanded(
                          child: SingleChildScrollView(
                            child: Column(
                              children: instructions
                                  .map((instruction) => Padding(
                                padding:
                                const EdgeInsets.only(bottom: 8.0),
                                child: Text(
                                  instruction,
                                  style: const TextStyle(fontSize: 16),
                                ),
                              )).toList(),
                            ),
                          ),
                        ),
                        const SizedBox(height: 20),
                        Center(
                          child: ElevatedButton(
                            onPressed: () {
                              Navigator.push(context, PageTransition(
                                  child: QuesScreen(),
                                  type: PageTransitionType.fade,
                                  duration: const Duration(milliseconds: 500),
                              ));
                            },
                            style: ElevatedButton.styleFrom(
                              backgroundColor: Colors.yellowAccent,
                              padding: const EdgeInsets.symmetric(horizontal: 40, vertical: 12),
                            ),
                            child: const Text(
                              "Start",
                              style: TextStyle(color: Colors.black, fontSize: 18),
                            ),
                          ),
                        )
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}