import 'package:flutter/material.dart';
import 'package:quizmanage/Client/Dashboard.dart';
import 'package:page_transition/page_transition.dart';

class Down extends StatelessWidget {
  const Down({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.lightBlueAccent,
      appBar: AppBar(
        title: Text("Question Banks"),
        centerTitle: true,
        backgroundColor: Colors.blueAccent,
        leading: IconButton(
          icon: Icon(Icons.arrow_back),
          onPressed: () {
            Navigator.push(context, PageTransition(child: const MainPage(), type: PageTransitionType.fade));
          },
        ),
      ),
      body: Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(colors: [Colors.white38,Colors.lightBlueAccent],
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
          ),
        ),
        child: ListView(
          padding: EdgeInsets.all(10),
          children: [
            _buildQuestionBankCard("Math Quiz Bank", "100+ math questions"),
            _buildQuestionBankCard("Science Quiz Bank", "Covers physics, chemistry, and biology"),
            _buildQuestionBankCard("History Quiz Bank", "Important historical events and figures"),
          ],
        ),
      ),
    );
  }
  Widget _buildQuestionBankCard(String title, String description) {
    return Card(
      margin: EdgeInsets.symmetric(vertical: 10),
      child: ListTile(
        title: Text(title,style: TextStyle(fontWeight: FontWeight.bold),),
        subtitle: Text(description),
        trailing: SizedBox(
          height: 40,
          child: ElevatedButton(
            onPressed: () {
              print("downloaded successfully");
            },
            style: ElevatedButton.styleFrom(
              backgroundColor: Colors.blueAccent
            ),
            child: Text("Download",style: TextStyle(color: Colors.white,fontWeight: FontWeight.bold),),
          ),
        ),
      ),
    );
  }
}