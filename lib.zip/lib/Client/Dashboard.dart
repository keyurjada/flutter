import 'package:flutter/material.dart';
import 'package:carousel_slider/carousel_slider.dart';
import 'profilePage.dart';
import 'historyPage.dart';

class MainPage extends StatefulWidget {
  const MainPage({super.key});

  @override
  _MainScreenState createState() => _MainScreenState();
}
class _MainScreenState extends State<MainPage> {
  int _selectedIndex = 0;

  static final List<Widget> _pages = [
    const Dashboard(),
    Profile(),
    History(),
  ];

  void _onItemTapped(int index) {
    setState(() {
      _selectedIndex = index;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: _pages[_selectedIndex],
      bottomNavigationBar: BottomNavigationBar(
        currentIndex: _selectedIndex,
        onTap: _onItemTapped,
        items: const [
          BottomNavigationBarItem(icon: Icon(Icons.home,color: Colors.black,), label: "Home"),
          BottomNavigationBarItem(icon: Icon(Icons.person,color: Colors.black,), label: "Profile"),
          BottomNavigationBarItem(icon: Icon(Icons.history,color: Colors.black,), label: "History"),
        ],
      ),
    );
  }
}
class Dashboard extends StatelessWidget {
  const Dashboard({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.blueAccent,
      appBar: AppBar(
        title: Text("Home",style: TextStyle(fontWeight: FontWeight.bold),),
        centerTitle: true,
        backgroundColor: Colors.lightBlueAccent,
      ),
      body: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            colors: [Colors.white38, Colors.lightBlueAccent],
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
          ),
        ),
        child: SafeArea(
          child: Padding(
            padding: const EdgeInsets.all(16.0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    CircleAvatar(
                      backgroundColor: Colors.white,
                      radius: 24,
                      child: Icon(Icons.person, color: Colors.black),
                    ),
                    const SizedBox(width: 10),
                    Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const Text(
                          "User Name",
                          style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                        ),
                        Container(
                          padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                          decoration: BoxDecoration(
                            color: Colors.grey,
                            borderRadius: BorderRadius.circular(10),
                          ),
                          child: const Text(
                            "User",
                            style: TextStyle(color: Colors.white, fontSize: 12,fontWeight: FontWeight.bold),
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
                const SizedBox(height: 16),
                TextField(
                  decoration: InputDecoration(
                    hintText: "Search quizzes",
                    prefixIcon: const Icon(Icons.search),
                    filled: true,
                    fillColor: Colors.white,
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(12),
                      borderSide: BorderSide.none,
                    ),
                  ),
                ),
                const SizedBox(height: 16),
                Container(
                  padding: const EdgeInsets.all(16),
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(12),
                    boxShadow: [
                      BoxShadow(color: Colors.grey.withOpacity(0.3), blurRadius: 5),
                    ],
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Text("Quiz", style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
                      const Text("15 Questions"),
                      const SizedBox(height: 8),
                      LinearProgressIndicator(
                        value: 12 / 15,
                        backgroundColor: Colors.grey[300],
                        color: Colors.blue,
                      ),
                      const SizedBox(height: 4),
                      const Text("Progress: 12/15"),
                    ],
                  ),
                ),
                const SizedBox(height: 16),
                const Text("Quiz", style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
                const SizedBox(height: 8),
                CarouselSlider(
                  options: CarouselOptions(height: 150, autoPlay: true, enlargeCenterPage: true,enableInfiniteScroll: true),
                  items: [
                    "https://th.bing.com/th/id/OIP.PRjOe_WL5VGVgqyl04ai5QHaDu?w=344&h=175&c=7&r=0&o=5&dpr=1.1&pid=1.7",
                    "https://th.bing.com/th/id/OIP.GplH6RXkVVSMYmY4B4F_DgHaD_?w=271&h=180&c=7&r=0&o=5&dpr=1.1&pid=1.7",
                    "https://th.bing.com/th/id/OIP.IEU3IyE8irWtNkt5zEB44wHaEo?w=297&h=123&c=7&r=0&o=5&dpr=1.1&pid=1.7",
                    "https://th.bing.com/th/id/OIP.YxUj3hNdMjQ5e5tBhvhsBgHaD5?w=337&h=180&c=7&r=0&o=5&dpr=1.1&pid=1.7",
                    "https://th.bing.com/th/id/OIP.qpegqWN-X6gOGg1L_rVpmAHaEK?w=316&h=180&c=7&r=0&o=5&dpr=1.1&pid=1.7"
                  ].map((imageUrl) {
                    return Container(
                      margin: const EdgeInsets.symmetric(horizontal: 5.0),
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(12),
                        image: DecorationImage(
                          image: NetworkImage(imageUrl),
                          fit: BoxFit.cover,
                        ),
                      ),
                    );
                  }).toList(),
                ),
                const SizedBox(height: 16),
                const Text("More Quizzes", style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
                Expanded(
                  child: ListView(
                    children: List.generate(4, (index) {
                      return Container(
                        margin: const EdgeInsets.symmetric(vertical: 8),
                        padding: const EdgeInsets.all(16),
                        decoration: BoxDecoration(
                          color: Colors.white,
                          borderRadius: BorderRadius.circular(12),
                          boxShadow: [
                            BoxShadow(color: Colors.grey.withOpacity(0.3), blurRadius: 5),
                          ],
                        ),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: const [
                            Text("Type of quiz", style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
                            Text("Questions"),
                          ],
                        ),
                      );
                    }),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}