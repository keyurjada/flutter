import 'package:flutter/material.dart';
import 'package:quizmanage/Client/Dashboard.dart';
import 'package:page_transition/page_transition.dart';
import 'package:quizmanage/Client/downLoadQB.dart';
import 'package:quizmanage/Client/historyPage.dart';
import 'package:quizmanage/landingpage.dart';
import 'package:quizmanage/loginPage.dart';
import 'package:shared_preferences/shared_preferences.dart';

class Profile extends StatefulWidget {
  @override
  State<Profile> createState() => _ProfileState();
}

class _ProfileState extends State<Profile> {
  Future<void> logout(BuildContext context) async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    await prefs.clear();
    Navigator.pushAndRemoveUntil(
      context,
      MaterialPageRoute(builder: (context) => const Loginpage()),
          (route) => false,
    );
  }
  @override
  Widget build(BuildContext context) {
    return Scaffold(
        backgroundColor: Colors.blueAccent,
        appBar: AppBar(
          title: Text("Profile"),
          backgroundColor: Colors.lightBlueAccent,
          leading: IconButton(
            icon: Icon(Icons.arrow_back),
            onPressed: () {
              Navigator.push(context, PageTransition(child: const MainPage(), type: PageTransitionType.fade));
            },
          ),
        ),
        body: Container(
          decoration: const BoxDecoration(
            gradient: LinearGradient(
              colors: [Colors.white38, Colors.lightBlueAccent],
              begin: Alignment.topCenter,
              end: Alignment.bottomCenter,
            ),
          ),
          child: Padding(
            padding: const EdgeInsets.all(16.0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                CircleAvatar(
                  radius: 50,
                  backgroundColor: Colors.white,
                  child: Icon(Icons.person, size: 50, color: Colors.black),
                ),
                SizedBox(height: 15),
                Text(
                  "Username",
                  style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
                ),
                Container(
                    padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                    decoration: BoxDecoration(
                      color: Colors.grey,
                      borderRadius: BorderRadius.circular(10),
                    ),
                    child: Text("user", style: TextStyle(color: Colors.white, fontSize: 12,fontWeight: FontWeight.bold),)
                ),
                SizedBox(height: 20),
                _buildMenuItem(Icons.home, "Home",()=>Navigator.push(context, PageTransition(child: const MainPage(), type: PageTransitionType.fade))),
                _buildMenuItem(Icons.history, "History",()=>Navigator.push(context, PageTransition(child: History(), type: PageTransitionType.fade))),
                _buildMenuItem(Icons.book, "Question Bank",()=>Navigator.push(context, PageTransition(child: const Down(), type: PageTransitionType.fade))),
                Spacer(),
                ElevatedButton(
                  onPressed: (){
                    logout(context);
                  },
                  child: Text("Logout"),
                ),

                SizedBox(height: 10),
                ElevatedButton.icon(
                  onPressed: () {
                    Navigator.push(context, PageTransition(child: LandingPage(), type: PageTransitionType.fade));
                  },
                  icon: Icon(Icons.delete),
                  label: Text("Delete account",style: TextStyle(fontWeight: FontWeight.bold,color: Colors.white),),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.red,
                    minimumSize: Size(double.infinity, 50),
                  ),
                ),
              ],
            ),
          ),
        ),
      );
  }

  Widget _buildMenuItem(IconData icon, String title,VoidCallback onTap) {
    return Card(
      margin: EdgeInsets.symmetric(vertical: 8),
      child: ListTile(
        leading: Icon(icon, color: Colors.grey[700]),
        title: Text(title),
        trailing: Icon(Icons.arrow_forward_ios, size: 16),
        onTap: onTap,
      ),
    );
  }
}