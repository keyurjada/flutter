import 'package:flutter/material.dart';
import 'package:page_transition/page_transition.dart';
import 'package:quizmanage/Client/Dashboard.dart';
import 'package:flutter_rating_bar/flutter_rating_bar.dart';

class Score extends StatelessWidget {
  final int correctAnswers;
  final int totalQuestions;

  const Score({
    Key? key,
    required this.correctAnswers,
    required this.totalQuestions,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.blueAccent,
      appBar: AppBar(
        title: Center(child: Text("Your Score",style: TextStyle(fontWeight: FontWeight.bold),)),
        backgroundColor: Colors.lightBlueAccent,
        leading: IconButton(
          icon: Icon(Icons.arrow_back),
          onPressed: () {
            Navigator.push(context, PageTransition(child: const MainPage(), type: PageTransitionType.fade));
          },
        ),
      ),
      body: Center(
        child: Container(
          decoration: const BoxDecoration(
            gradient: LinearGradient(
              colors: [Colors.white38, Colors.lightBlueAccent],
              begin: Alignment.topCenter,
              end: Alignment.bottomCenter,
            ),
          ),
          padding: const EdgeInsets.all(16.0),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Text(
                "Correct Answer: $correctAnswers/$totalQuestions",
                style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
              ),
              const SizedBox(height: 20),
              CircleAvatar(
                radius: 40,
                backgroundColor: Colors.white,
                child: Icon(Icons.person, size: 40),
              ),
              const SizedBox(height: 10),
              Text("User", style: TextStyle(fontSize: 16)),
              const SizedBox(height: 20),
              Text(
                "Congratulations! You have completed this quiz.",
                textAlign: TextAlign.center,
                style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
              ),
              const SizedBox(height: 10),
              Text(
                "Let's keep testing more knowledge by playing more quizzes.",
                textAlign: TextAlign.center,
                style: TextStyle(fontSize: 14),
              ),
              const SizedBox(height: 20),
              ElevatedButton(
                onPressed: () {
                  Navigator.push(context, PageTransition(child: const MainPage(), type: PageTransitionType.fade));
                },style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.yellowAccent,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(12)
                  ),
                ),child: Text("Explore more",style: TextStyle(fontSize: 20,fontWeight: FontWeight.bold),),
              ),
          const SizedBox(height: 30),
          const Text(
            "Rate this Quiz:",
            style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
          ),
              const SizedBox(height: 10),
              RatingBar.builder(
                initialRating: 0,
                minRating: 1,
                direction: Axis.horizontal,
                allowHalfRating: true,
                itemCount: 5,
                itemPadding: const EdgeInsets.symmetric(horizontal: 4.0),
                itemBuilder: (context, _) => const Icon(
                  Icons.star,
                  color: Colors.amber,
                ),
                onRatingUpdate: (rating) {
                  print("Rating: $rating");
                },
              ),
            ],
          ),
        ),
      ),
    );
  }
}
