import 'package:flutter/material.dart';
import 'package:quizmanage/Client/Dashboard.dart';
import 'package:page_transition/page_transition.dart';
import 'package:quizmanage/Client/scorePage.dart';

class History extends StatelessWidget {
  final List<Map<String, dynamic>> quizHis = [
    {"title": "Quiz", "total": 15, "progress": 12, "date": "Jan 29, 2025"},
    {"title": "Quiz", "total": 20, "progress": 14, "date": "Jan 28, 2025"},
    {"title": "Quiz", "total": 10, "progress": 8, "date": "Jan 27, 2025"},
    {"title": "Quiz", "total": 25, "progress": 16, "date": "Jan 26, 2025"},
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        backgroundColor: Colors.blueAccent,
        appBar: AppBar(
          title: Text("History"),
          backgroundColor: Colors.lightBlueAccent,
          leading: IconButton(
            icon: Icon(Icons.arrow_back),
            onPressed: () {
              Navigator.push(context, MaterialPageRoute(builder: (context)=>MainPage()));
            },
          ),
        ),
        body: Container(
          decoration: const BoxDecoration(
            gradient: LinearGradient(
              colors: [Colors.white38, Colors.lightBlueAccent],
              begin: Alignment.topCenter,
              end: Alignment.bottomCenter,
            ),
          ),
          child: Padding(
            padding: const EdgeInsets.all(16.0),
            child: ListView.builder(
              itemCount: quizHis.length,
              itemBuilder: (context, index) {
                final quiz = quizHis[index];
                return _buildQuizCard(quiz,()=>Navigator.push(context,PageTransition(child: const Score(correctAnswers: 12, totalQuestions: 15), type: PageTransitionType.fade)));
              },
            ),
          ),
        ),
      );
  }
  Widget _buildQuizCard(Map<String, dynamic> quiz,VoidCallback onPressed) {
    double progress = quiz["progress"] / quiz["total"];
    return Card(
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(15)),
      margin: EdgeInsets.only(bottom: 12),
      child: Padding(
        padding: const EdgeInsets.all(12.0),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Container(
              width: 60,
              height: 60,
              decoration: BoxDecoration(
                color: Colors.yellowAccent,
                borderRadius: BorderRadius.circular(8),
              ),
            ),
            SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    quiz["title"],
                    style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                  ),
                  Text("${quiz["total"]} Questions", style: TextStyle(color: Colors.grey[700])),
                  SizedBox(height: 8),
                  LinearProgressIndicator(
                    value: progress,
                    backgroundColor: Colors.grey[300],
                    color: Colors.red,
                    minHeight: 6,
                  ),
                  SizedBox(height: 4),
                  Text(
                    "Progress: ${quiz["progress"]}/${quiz["total"]}",
                    style: TextStyle(fontSize: 14),
                  ),
                  SizedBox(height: 4),
                  Text("Date: ${quiz["date"]}",
                      style: TextStyle(color: Colors.grey[600], fontSize: 12)),
                ],
              ),
            ),
            SizedBox(width: 8),
            IconButton(
              icon: Icon(Icons.visibility, color: Colors.blue),
              onPressed: onPressed
            ),
          ],
        ),
      ),
    );
  }
}
